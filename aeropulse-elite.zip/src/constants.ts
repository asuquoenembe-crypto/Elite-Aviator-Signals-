/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SignalWindow {
  minutes: number[];
  odds: string;
}

export const SIGNAL_WINDOWS: SignalWindow[] = [
  { minutes: [1, 2], odds: "10x-23x" },
  { minutes: [5, 6], odds: "6x-15x" },
  { minutes: [9, 10], odds: "15x-40x" },
  { minutes: [12, 13], odds: "8x-20x" },
  { minutes: [15, 16], odds: "20x-35x" },
  { minutes: [18, 19], odds: "15x-29x" },
  { minutes: [21, 22], odds: "10x-25x" },
  { minutes: [25, 26], odds: "25x-55x" },
  { minutes: [29, 30], odds: "10x-23x" }, // Cycling back
  { minutes: [32, 33], odds: "6x-15x" },
  { minutes: [35, 36], odds: "15x-40x" },
  { minutes: [38, 39], odds: "8x-20x" },
  { minutes: [41, 42], odds: "20x-35x" },
  { minutes: [45, 46], odds: "15x-29x" },
  { minutes: [48, 49], odds: "10x-25x" },
  { minutes: [51, 52], odds: "25x-55x" },
  { minutes: [54, 55], odds: "10x-23x" },
  { minutes: [58, 59], odds: "6x-15x" },
];

export const SPECIAL_ALERT_MINUTES = [25, 26];
export const SPECIAL_ALERT_MESSAGE = "Hold tight, Pilot! Entering a high-velocity zone. Odds may play above the range given—stay sharp!";

export type Mode = 'NORMAL' | 'BONUS' | 'RECOVERY';

export interface UserState {
  nickname: string;
  streak: ('YES' | 'NO')[];
  mode: Mode;
}
