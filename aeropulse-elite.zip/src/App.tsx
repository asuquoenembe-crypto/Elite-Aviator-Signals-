/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plane, 
  ChevronRight, 
  Clock, 
  Zap, 
  Trophy, 
  AlertTriangle,
  RefreshCw,
  LogOut,
  Activity,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  SIGNAL_WINDOWS, 
  SPECIAL_ALERT_MINUTES, 
  SPECIAL_ALERT_MESSAGE,
  Mode,
  SignalWindow
} from './constants';

// UI Components
const BackgroundBlobs = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
    <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-magenta opacity-[0.07] rounded-full blur-[120px]"></div>
    <div className="absolute bottom-[-10%] right-[-5%] w-[500px] h-[500px] bg-purple-glow opacity-[0.1] rounded-full blur-[100px]"></div>
    <div className="absolute top-[20%] right-[10%] w-[300px] h-[300px] bg-magenta opacity-[0.05] rounded-full blur-[80px]"></div>
  </div>
);

interface OnboardingProps {
  nickname: string;
  setNickname: (val: string) => void;
  onEngage: (e: React.FormEvent) => void;
}

const Onboarding = ({ nickname, setNickname, onEngage }: OnboardingProps) => (
  <motion.div 
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    className="flex flex-col items-center justify-center min-h-screen p-6 relative bg-obsidian text-white overflow-hidden"
  >
    <BackgroundBlobs />
    
    <motion.div 
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="w-full max-w-[500px] p-10 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-2xl shadow-2xl relative z-10"
    >
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-gradient-to-b from-magenta to-transparent rounded-full opacity-20 blur-xl"></div>
      
      <div className="text-center mb-10">
        <div className="inline-block p-5 mb-6 rounded-full bg-magenta/10 border border-magenta/20 shadow-[inset_0_0_20px_rgba(225,0,255,0.1)] relative">
          <motion.div
            animate={{ y: [0, -5, 0], rotate: [0, -2, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            <Plane className="w-16 h-16 text-magenta opacity-80" />
          </motion.div>
        </div>
        <h1 className="text-4xl font-display font-black tracking-tighter uppercase mb-2">
          AeroPulse <span className="text-magenta">Elite</span>
        </h1>
        <p className="text-white/50 text-sm font-sans">Precision Timing. Maximum Multiplier. Enter your callsign to begin.</p>
      </div>

      <form onSubmit={onEngage} className="space-y-8">
        <div className="relative group">
          <label className="absolute -top-2.5 left-4 px-2 bg-obsidian text-[10px] uppercase tracking-widest text-magenta font-extrabold z-10">
            Pilot Nickname
          </label>
          <input 
            type="text"
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            placeholder="_VIPER_"
            className="w-full bg-white/5 border border-white/20 rounded-xl px-5 py-4 text-xl font-mono outline-none focus:border-magenta focus:ring-1 focus:ring-magenta/30 transition-all placeholder:text-white/10"
            autoFocus
          />
        </div>
        
        <button 
          type="submit"
          className="w-full py-5 bg-magenta hover:bg-magenta/90 text-white font-display font-black rounded-xl tracking-[0.2em] uppercase shadow-[0_0_30px_rgba(225,0,255,0.3)] transition-all flex items-center justify-center gap-3 group"
        >
          Lock Flight Path
          <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
        </button>
      </form>

      <div className="mt-10 pt-8 border-t border-white/5 text-center">
        <p className="text-[11px] text-white/20 uppercase tracking-[0.4em] font-bold">Authorized Access Only</p>
      </div>
    </motion.div>
  </motion.div>
);

interface DashboardProps {
  nickname: string;
  mode: Mode;
  currentTime: Date;
  activeSignal: SignalWindow | undefined;
  streak: ('YES' | 'NO')[];
  showFeedback: boolean;
  handleFeedback: (v: 'YES' | 'NO') => void;
  onLogout: () => void;
  onGenerate: () => void;
  generatedSignal: SignalWindow | null;
  isGenerating: boolean;
}

const Dashboard = ({ 
  nickname, 
  mode, 
  currentTime, 
  activeSignal, 
  streak, 
  showFeedback, 
  handleFeedback, 
  onLogout,
  onGenerate,
  generatedSignal,
  isGenerating
}: DashboardProps) => {
  const bgColor = mode === 'BONUS' ? 'bg-gradient-to-br from-purple-deep via-gold/10 to-magenta/10' : 
                 mode === 'RECOVERY' ? 'bg-gradient-to-br from-[#0a0a1a] to-[#1a1a2e]' : 
                 'bg-obsidian';

  const glowClass = mode === 'BONUS' ? 'gold-glow text-gold' : 
                    mode === 'RECOVERY' ? 'text-blue-400 opacity-50' : 
                    'magenta-glow text-magenta';

  return (
    <div className={`min-h-screen ${bgColor} text-white font-sans flex flex-col relative overflow-hidden transition-colors duration-1000`}>
      <BackgroundBlobs />

      {/* Header */}
      <header className="h-20 border-b border-white/10 flex items-center justify-between px-6 md:px-10 relative z-10 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-gradient-to-br from-magenta to-purple-glow rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(225,0,255,0.4)]">
            <Plane className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-display font-bold tracking-tighter uppercase">
              AeroPulse <span className="text-magenta">Elite</span>
            </h1>
            <p className="text-[10px] text-white/40 uppercase tracking-widest leading-none">Precision Timing. Maximum Multiplier.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-6 md:gap-8">
          <div className="text-right hidden sm:block">
            <div className="text-[10px] text-white/40 uppercase tracking-widest">System Status</div>
            <div className={`text-sm font-mono flex items-center justify-end gap-2 ${mode === 'RECOVERY' ? 'text-red-500' : 'text-success success-glow'}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${mode === 'RECOVERY' ? 'bg-red-500 animate-pulse' : 'bg-success'}`}></span> 
              {mode === 'RECOVERY' ? 'RE-SYNCING' : 'ONLINE'}
            </div>
          </div>
          <div className="h-10 w-px bg-white/10 hidden sm:block"></div>
          <div className="text-right">
            <div className="text-[10px] text-white/40 uppercase tracking-widest">Global Pulse</div>
            <div className="text-xl font-mono">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard Layout */}
      <main className="flex-1 flex flex-col lg:flex-row px-6 md:px-10 py-8 gap-8 relative z-10 overflow-y-auto lg:overflow-hidden">
        {/* Left Column: Generator & Active Status */}
        <div className="flex-[1.4] flex flex-col gap-6 lg:overflow-y-auto lg:pr-2 custom-scrollbar">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-between items-end"
          >
            <div className="space-y-2">
              <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-magenta italic">Flight Mission Active</h2>
              <h3 className="text-4xl font-display font-black tracking-tighter">Pilot: {nickname}</h3>
            </div>
            
            <button 
              onClick={onGenerate}
              disabled={isGenerating}
              className="px-8 py-4 bg-magenta text-white font-display font-black rounded-2xl tracking-[0.1em] uppercase shadow-[0_0_30px_rgba(225,0,255,0.4)] hover:bg-magenta/90 active:scale-95 transition-all flex items-center gap-3 disabled:opacity-50"
            >
              {isGenerating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-white" />}
              Generate Signal
            </button>
          </motion.div>

          {/* Generated/Active Signal Display */}
          <AnimatePresence mode="wait">
            {(generatedSignal || activeSignal) ? (
              <motion.div 
                key={generatedSignal ? `gen-${generatedSignal.minutes[0]}` : 'active'}
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 1.05, opacity: 0 }}
                className={`relative p-8 md:p-12 rounded-[40px] ${mode === 'BONUS' ? 'bg-gold/10 border-gold/30 gold-border-glow' : 'bg-magenta/5 border-magenta/20 magenta-border-glow'} border backdrop-blur-3xl shadow-2xl overflow-hidden min-h-[400px] flex flex-col items-center justify-center text-center`}
              >
                <div className="absolute top-0 right-0 p-8">
                  <div className={`w-3 h-3 rounded-full animate-ping ${generatedSignal ? 'bg-white' : 'bg-magenta'}`} />
                </div>
                
                <div className="relative z-10 space-y-8 w-full">
                  <div className="inline-block p-6 rounded-full bg-magenta/10 border border-magenta/20 shadow-[0_0_40px_rgba(225,0,255,0.1)] relative">
                     <Zap className="w-16 h-16 text-magenta" />
                     <div className="absolute inset-0 bg-magenta/20 blur-2xl rounded-full" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <div className="space-y-2">
                      <span className="text-xs font-black uppercase tracking-[0.5em] text-white/40 block">Timing Window</span>
                      <h4 className="text-5xl md:text-6xl font-mono font-bold tracking-tighter">
                        :{(generatedSignal || activeSignal)?.minutes[0].toString().padStart(2, '0')} - :{(generatedSignal || activeSignal)?.minutes[1].toString().padStart(2, '0')}
                      </h4>
                    </div>
                    
                    <div className="space-y-2">
                      <span className="text-xs font-black uppercase tracking-[0.5em] text-magenta/60 block">Target Multiplier</span>
                      <h4 className={`text-6xl md:text-7xl font-display font-black tracking-tighter leading-none ${glowClass}`}>
                        {(generatedSignal || activeSignal)?.odds}
                      </h4>
                    </div>
                  </div>
                  
                  <div className="pt-8 border-t border-white/5 w-full">
                    <p className="text-white/40 font-mono text-sm tracking-widest animate-pulse uppercase">
                      {generatedSignal ? 'Predicted High-Value Pulse Detected' : 'Analyzing Active Network Signal...'}
                    </p>
                  </div>
                </div>

                {/* Animation rings */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 border border-magenta/5 rounded-full animate-pulse" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-magenta/5 rounded-full animate-ping-slow overflow-hidden" />
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="idle-state"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-16 rounded-[40px] bg-white/[0.02] border border-white/5 backdrop-blur-xl flex flex-col items-center justify-center text-center space-y-6"
              >
                <RefreshCw className="w-16 h-16 text-white/10 animate-spin-slow" />
                <div>
                  <h3 className="text-2xl font-display font-bold text-white/60 uppercase tracking-widest">Awaiting Command</h3>
                  <p className="text-white/20 mt-2 max-w-xs mx-auto">Initiate a pulse scan to reveal the nearest high-velocity odds window.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Alerts & Mode Status */}
        <div className="flex-1 flex flex-col gap-6 lg:overflow-y-auto custom-scrollbar lg:max-w-md">
          {/* Status Indicators */}
          <div className="grid grid-cols-2 gap-4">
             <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
                <p className="text-[10px] text-white/40 uppercase font-black tracking-widest mb-1">Win Ratio</p>
                <p className="text-2xl font-mono text-success">96.4%</p>
             </div>
             <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
                <p className="text-[10px] text-white/40 uppercase font-black tracking-widest mb-1">Active Streak</p>
                <div className="flex justify-center gap-1.5 pt-1">
                   {[...Array(3)].map((_, i) => (
                    <div key={i} className={`w-3 h-1.5 rounded-full ${streak[streak.length - 1 - i] === 'YES' ? 'bg-success' : 'bg-white/10'}`} />
                  ))}
                </div>
             </div>
          </div>

          {/* Mode Overlay Messages */}
          <AnimatePresence>
            {mode === 'BONUS' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-8 rounded-3xl bg-gold shadow-[0_0_50px_rgba(255,215,0,0.3)] text-obsidian relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4 opacity-20">
                  <Sparkles className="w-24 h-24 rotate-12" />
                </div>
                <h3 className="text-3xl font-display font-black uppercase italic tracking-tighter mb-2">ABSOLUTE LEGEND!</h3>
                <p className="font-bold text-lg leading-tight uppercase opacity-80 tracking-tight">Bonus Mode Unlocked — Flight elevation maximized!</p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Alert Protocol Section */}
          <div className="flex-1 p-8 rounded-2xl bg-gradient-to-br from-purple-deep via-obsidian to-transparent border border-white/10 relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
              <AlertTriangle className="w-32 h-32 text-magenta" />
            </div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-6">Alert Protocol</h3>
            
            <AnimatePresence mode="wait">
              {SPECIAL_ALERT_MINUTES.includes(currentTime.getMinutes()) ? (
                <motion.div 
                  key="alert-active"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-4 h-full flex flex-col"
                >
                  <p className="text-2xl font-light italic leading-relaxed text-magenta/90">
                    "{SPECIAL_ALERT_MESSAGE}"
                  </p>
                  <div className="mt-auto pt-6 border-t border-white/10 flex items-center justify-between font-mono">
                     <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Velocity Level</span>
                     <span className="text-xl text-magenta">CRITICAL</span>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="alert-idle"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col"
                >
                   {mode === 'RECOVERY' ? (
                     <div className="space-y-4">
                       <h3 className="text-2xl font-display font-bold text-blue-400">Recovery Mode</h3>
                       <p className="text-sm leading-relaxed opacity-60">
                         The board is being reshuffled due to high volume of winners. Entering recovery protocol to ensure next sync is optimal.
                       </p>
                     </div>
                   ) : (
                     <p className="text-white/30 text-sm italic mb-8 leading-relaxed">System monitoring atmospheric data. No critical velocity alerts for the current elevation.</p>
                   )}
                  <div className="mt-auto pt-6 border-t border-white/10 flex items-center justify-between">
                     <div className="flex flex-col">
                       <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Session Integrity</span>
                       <span className="text-2xl font-mono font-bold text-success success-glow">VERIFIED</span>
                     </div>
                     <Trophy className="w-10 h-10 text-white/10" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Mobile Actions Footer */}
      <div className="lg:hidden p-4 bg-white/5 border-t border-white/10 flex justify-around">
         <button onClick={onGenerate} className="flex flex-col items-center gap-1">
            <Zap className={`w-5 h-5 ${isGenerating ? 'animate-pulse' : ''} text-magenta`} />
            <span className="text-[8px] uppercase text-white/40 font-bold">Scan Signal</span>
         </button>
         <button onClick={onLogout} className="flex flex-col items-center gap-1">
           <LogOut className="w-5 h-5 text-white/30" />
           <span className="text-[8px] uppercase text-white/40 font-bold">Exit</span>
         </button>
      </div>

      {/* Desktop Sticky Footer */}
      <footer className="h-12 shrink-0 bg-white/[0.02] border-t border-white/5 flex items-center justify-between px-6 md:px-10 text-[10px] uppercase tracking-[0.2em] text-white/30 relative z-20">
        <div className="hidden sm:block">Session ID: AE-{Math.floor(Date.now()/100000).toString(16).toUpperCase()}</div>
        <div className="flex gap-4 md:gap-8">
          <span className="flex items-center gap-1.5"><span className="w-1 h-1 bg-magenta rounded-full"></span> Secure Node</span>
          <span className="flex items-center gap-1.5"><span className="w-1 h-1 bg-magenta rounded-full"></span> Neural Uplink</span>
        </div>
        <div className="hidden md:block">Ver 4.1.0-Elite Build 9402</div>
        <button 
          onClick={onLogout}
          className="sm:hidden flex items-center gap-2 hover:text-white transition-colors"
        >
          <LogOut className="w-3 h-3" /> EXIT
        </button>
      </footer>

      {/* Feedback Modal Overlay */}
      <AnimatePresence>
        {showFeedback && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-obsidian/90 backdrop-blur-xl z-[100] flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md bg-white/5 border border-white/10 p-10 rounded-[40px] text-center space-y-8 backdrop-blur-2xl shadow-2xl relative"
            >
              <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 bg-magenta/20 rounded-full blur-2xl" />
              
              <div className="w-20 h-20 bg-magenta/10 border border-magenta/20 rounded-full flex items-center justify-center mx-auto shadow-[inset_0_0_20px_rgba(225,0,255,0.1)]">
                <Trophy className="w-10 h-10 text-magenta" />
              </div>
              
              <div>
                <h3 className="text-3xl font-display font-black mb-3 italic tracking-tighter">MISSION RECAP</h3>
                <p className="text-white/50 text-lg">Hope you played! Did you win it, Gee?</p>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <button 
                  onClick={() => handleFeedback('YES')}
                  className="py-5 bg-success hover:bg-success/90 rounded-2xl font-display font-black text-obsidian tracking-wider transform hover:scale-[1.02] transition-all shadow-xl shadow-success/10"
                >
                  YES
                </button>
                <button 
                  onClick={() => handleFeedback('NO')}
                  className="py-5 bg-white/10 hover:bg-white/20 border border-white/10 rounded-2xl font-display font-black text-white tracking-wider transform hover:scale-[1.02] transition-all"
                >
                  NO
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function App() {
  const [nickname, setNickname] = useState<string>('');
  const [isOnboarded, setIsOnboarded] = useState<boolean>(false);
  const [streak, setStreak] = useState<('YES' | 'NO')[]>([]);
  const [mode, setMode] = useState<Mode>('NORMAL');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastSignalWindow, setLastSignalWindow] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState<boolean>(false);
  const [generatedSignal, setGeneratedSignal] = useState<SignalWindow | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const PERSISTENCE_KEY = 'aeropulse_elite_user_v1';
  const EXPIRATION_TIME = 48 * 60 * 60 * 1000; // 48 hours

  // Initialize from LocalStorage
  useEffect(() => {
    const savedData = localStorage.getItem(PERSISTENCE_KEY);
    if (savedData) {
      try {
        const { nickname: savedName, streak: savedStreak, timestamp } = JSON.parse(savedData);
        const now = Date.now();
        
        if (now - timestamp < EXPIRATION_TIME) {
          setNickname(savedName);
          setStreak(savedStreak || []);
          setIsOnboarded(true);
        } else {
          localStorage.removeItem(PERSISTENCE_KEY);
        }
      } catch (e) {
        console.error('Failed to parse persistence data', e);
        localStorage.removeItem(PERSISTENCE_KEY);
      }
    }
  }, []);

  // Update persistence whenever nickname or streak changes
  useEffect(() => {
    if (isOnboarded && nickname) {
      const data = {
        nickname,
        streak,
        timestamp: Date.now() // Keep it active if they use it? Or fixed from first login?
        // User said "permanent for 48 hours", usually means from entry.
        // But refreshing the timestamp on activity is often better UX unless strictly "locked window".
        // Let's stick to the 48h from initial/last update.
      };
      
      // If we want it strictly 48h from FIRST login, we should only set timestamp if not exists.
      // But the user said "permanent for 48 hours", if they come back after 47h, 
      // maybe it should extend? Or just die at 48h?
      // Usually "permanent for X hours" in these types of requests means a cookie-like session.
      // I'll preserve the original timestamp if it exists to strictly respect the 48h limit from first entry.
      
      const saved = localStorage.getItem(PERSISTENCE_KEY);
      let finalTimestamp = Date.now();
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          finalTimestamp = parsed.timestamp || finalTimestamp;
        } catch(e) {}
      }

      localStorage.setItem(PERSISTENCE_KEY, JSON.stringify({
        nickname,
        streak,
        timestamp: finalTimestamp
      }));
    }
  }, [nickname, streak, isOnboarded]);

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Determine current signal
  const activeSignal = useMemo(() => {
    const minutes = currentTime.getMinutes();
    return SIGNAL_WINDOWS.find(window => window.minutes.includes(minutes));
  }, [currentTime]);

  // Handle signal window transitions (trigger feedback)
  useEffect(() => {
    const minutes = currentTime.getMinutes();
    if (activeSignal) {
      setLastSignalWindow(activeSignal.minutes[1]);
    } else if (lastSignalWindow !== null) {
      const waitTime = (minutes - lastSignalWindow + 60) % 60;
      if (waitTime >= 1 && waitTime <= 2) {
        setShowFeedback(true);
        setLastSignalWindow(null);
        setGeneratedSignal(null); // Clear generated signal on session end
      } else if (waitTime > 2) {
        setLastSignalWindow(null);
      }
    }
  }, [activeSignal, currentTime, lastSignalWindow]);

  // Mode Logic based on streak
  useEffect(() => {
    if (streak.length >= 3) {
      const lastThree = streak.slice(-3);
      if (lastThree.every(v => v === 'YES')) {
        setMode('BONUS');
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FFD700', '#E100FF', '#FFFFFF']
        });
      } else if (lastThree.every(v => v === 'NO')) {
        setMode('RECOVERY');
      } else {
        setMode('NORMAL');
      }
    } else {
      setMode('NORMAL');
    }
  }, [streak]);

  const handleOnboard = (e: React.FormEvent) => {
    e.preventDefault();
    if (nickname.trim()) {
      setIsOnboarded(true);
      // Immediately set persistence on first onboard
      localStorage.setItem(PERSISTENCE_KEY, JSON.stringify({
        nickname: nickname.trim(),
        streak: [],
        timestamp: Date.now()
      }));
    }
  };

  const handleFeedback = (response: 'YES' | 'NO') => {
    setStreak(prev => [...prev, response]);
    setShowFeedback(false);
  };

  const handleLogout = () => {
    // If they explicitly log out, clear the persistence
    localStorage.removeItem(PERSISTENCE_KEY);
    setIsOnboarded(false);
    setNickname('');
    setStreak([]);
    setGeneratedSignal(null);
  };

  const handleGenerate = () => {
    setIsGenerating(true);
    
    // Simulate brief scan delay
    setTimeout(() => {
      const currentMin = currentTime.getMinutes();
      
      // Find nearest upcoming signal (or current one)
      let nearest = SIGNAL_WINDOWS.find(w => w.minutes[0] >= currentMin);
      
      // If no upcoming in this hour, wrap to first of next hour
      if (!nearest) {
        nearest = SIGNAL_WINDOWS[0];
      }
      
      setGeneratedSignal(nearest);
      setIsGenerating(false);
      
      // Small trigger feedback if NOT recovery mode
      if (mode !== 'RECOVERY') {
        confetti({
          particleCount: 20,
          spread: 40,
          origin: { y: 0.5, x: 0.5 },
          colors: ['#E100FF'],
          disableForced3d: true
        });
      }
    }, 400);
  };

  return (
    <div className="font-sans text-white">
      {isOnboarded ? (
        <Dashboard 
          nickname={nickname}
          mode={mode}
          currentTime={currentTime}
          activeSignal={activeSignal}
          streak={streak}
          showFeedback={showFeedback}
          handleFeedback={handleFeedback}
          onLogout={handleLogout}
          onGenerate={handleGenerate}
          generatedSignal={generatedSignal}
          isGenerating={isGenerating}
        />
      ) : (
        <Onboarding 
          nickname={nickname}
          setNickname={setNickname}
          onEngage={handleOnboard}
        />
      )}
    </div>
  );
}
